# --- Created by Ebean DDL
# To stop Ebean DDL generation, remove this comment and start using Evolutions

# --- !Ups

create table article (
  article_id                    bigint auto_increment not null,
  name                          varchar(255),
  price                         float not null,
  desc                          varchar(255),
  panier                        boolean default false not null,
  vendeur_id                    bigint,
  constraint pk_article primary key (article_id)
);

create table person (
  id                            bigint auto_increment not null,
  nom_entreprise                varchar(255),
  adresse                       varchar(255),
  email                         varchar(255),
  password                      varchar(255),
  constraint pk_person primary key (id)
);

create index ix_article_vendeur_id on article (vendeur_id);
alter table article add constraint fk_article_vendeur_id foreign key (vendeur_id) references person (id) on delete restrict on update restrict;


# --- !Downs

alter table article drop constraint if exists fk_article_vendeur_id;
drop index if exists ix_article_vendeur_id;

drop table if exists article;

drop table if exists person;


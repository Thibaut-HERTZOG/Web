package controllers;

import models.Person;
import views.html.*;
import play.mvc.*;
import java.util.List ; 
import play.data.* ;
import javax.inject.Inject; 
import play.i18n.MessagesApi;


/**
 * This controller contains an action to handle HTTP requests
 * to the application's home page.
 */
public class HomeControllerVendeur extends Controller {

    @Inject
    FormFactory formFactory; 
    Form <Person > personForm ;
    MessagesApi messagesApi;
    
    @Inject
    public HomeControllerVendeur(FormFactory formFactory, MessagesApi messagesApi) {
     this.personForm = formFactory.form(Person.class);
     this.messagesApi = messagesApi;
    }
    
    
    //Appel de la vue du formulaire pour un nouvel objet
    
    public Result newVendeur(Http.Request request) {
        personForm = formFactory.form(Person.class) ;
        return ok(newVendeur.render(personForm, request, messagesApi.preferred(request))) ; 
    }
    
    //Validation du formulaire et création de l'objet
    
    public Result okNewVendeur(Http.Request request) {
        Form<Person> pForm = personForm.bindFromRequest(request) ;
        if(pForm.hasErrors()) {
            return badRequest(newVendeur.render(pForm, request, messagesApi.preferred(request))) ;
        } else {
            Person a = pForm.get();
            a.save();
            return ok(okNewVendeur.render(a)) ;
        }    
    }

    
    //Appel de la vue montrant la liste de tous les objets
    
    public Result allVendeur(){
        List<Person> liste = Person.find.all();
        return ok(allVendeur.render(liste));
    }
    
    
    //Appel de la vue d'un objet par rapport a son ID
    
    public Result showVendeur(Long id){
        Person p = Person.find.byId(id) ;
        return ok(showVendeur.render(p)) ;
    }
    
    //Méthode de suppression d'un objet
    
    public Result deleteVendeur( Long id) {
        Person p = Person.find.byId(id) ;
        p.delete() ;
        return ok(deleteVendeur.render()) ;
    }
    
    
    //Méthode d'update d'un objet : appel de la vue d'un formulaire
    
    public Result updateVendeur(Long id, Http.Request request) {
         Person p = Person.find.byId(id) ;
         Form<Person> pForm = formFactory.form(Person.class ) ;
         pForm = pForm.fill(p);
         return ok(updateVendeur.render(pForm, id, request, messagesApi.preferred(request))) ; 
     }
    
    //Méthode de validation de l'update
    
    public Result updateOkVendeur(Long id, Http.Request request) {
       final Form<Person> pForm = personForm.bindFromRequest(request) ; 
        if (pForm.hasErrors()){
            return badRequest(newVendeur.render(pForm,request, messagesApi.preferred(request)));
        }
        else{
            Person a = pForm.get();
            a.setId(id);
            a.update();
        return ok(okNewVendeur.render(a)) ;
        }
    }
}

package controllers;

import models.Person;
import views.html.*;
import play.mvc.*;
import java.util.List ; 
import play.data.* ;
import javax.inject.Inject; 
import play.i18n.MessagesApi;


import play.libs.Files.TemporaryFile;
import play.mvc.Controller;
import play.mvc.Http;
import play.mvc.Result;

import java.nio.file.Paths;




public class HomeController extends Controller {
    
    //Appel de la vue de l'index
    
    public Result index(){
        return ok(index.render());
    }
    
}

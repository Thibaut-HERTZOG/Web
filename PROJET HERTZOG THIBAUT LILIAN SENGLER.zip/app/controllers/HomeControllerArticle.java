package controllers;

import models.Article;
import views.html.*;
import play.mvc.*;
import java.util.List ; 
import play.data.* ;
import javax.inject.Inject; 
import play.i18n.MessagesApi;


public class HomeControllerArticle extends Controller {

    @Inject
    FormFactory formFactory; 
    Form <Article > articleForm ;
    MessagesApi messagesApi;
    
    @Inject
    public HomeControllerArticle(FormFactory formFactory, MessagesApi messagesApi) {
     this.articleForm = formFactory.form(Article.class);
     this.messagesApi = messagesApi;
    }
    
    
    //Appel de la vue du formulaire pour un nouvel objet
    
    public Result newArticle(Http.Request request) {
        articleForm = formFactory.form(Article.class) ;
        return ok(newArticle.render(articleForm, request, messagesApi.preferred(request))) ; 
    }
    
    
    //Validation du formulaire et création de l'objet
    
    public Result okNewArticle(Http.Request request) {
        Form<Article> aForm = articleForm.bindFromRequest(request) ;
        if(aForm.hasErrors()) {
            return badRequest(newArticle.render(aForm, request, messagesApi.preferred(request))) ;
        } else {
            Article a = aForm.get();
            a.save();
            return ok(okNewArticle.render(a)) ;
        }    
    }
    
    
    //Appel de la vue montrant la liste de tous les objets
    
    public Result allArticle(){
        List<Article> liste = Article.find.all();
        return ok(allArticle.render(liste));
    }
    
    
    //Appel de la vue d'un objet par rapport a son ID
    
    public Result showArticle(Long articleId){
        Article p = Article.find.byId(articleId) ;
        return ok(showArticle.render(p)) ;
    }
    
    
    //Méthode de suppression d'un objet
    
    public Result deleteArticle(Long articleId) {
        Article p = Article.find.byId(articleId) ;
        p.delete() ;
        return ok(deleteArticle.render()) ;
    }
    
    //Méthode d'update d'un objet : appel de la vue d'un formulaire
    
    public Result updateArticle(Long articleId, Http.Request request) {
         Article p = Article.find.byId(articleId) ;
         Form<Article> pForm = formFactory.form(Article.class ) ;
         pForm = pForm.fill(p);
         return ok(updateArticle.render(pForm, articleId, request, messagesApi.preferred(request))) ; 
     }
    
    //Méthode de validation de l'update
    
    public Result updateOkArticle(Long articleId, Http.Request request) {
       final Form<Article> pForm = articleForm.bindFromRequest(request) ; 
        if (pForm.hasErrors()){
            return badRequest(newArticle.render(pForm,request, messagesApi.preferred(request)));
        }
        else{
            Article a = pForm.get();
            a.setArticleId(articleId);
            a.update();
        return ok(okNewArticle.render(a)) ;
        }
    }
    
    //Essaie d'une méthode pour ajouter un article dans le panier
    
    public Result panier(){
        List<Article> liste = Article.find.all();
        return ok(panier.render(liste));
    }
}
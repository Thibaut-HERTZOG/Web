package models ;

import java.util.*;
import io.ebean.*;
import javax.persistence.*;
import play.data.validation.Constraints.*;


@Entity
public class Person extends Model {
  
private static final long serialVersionUID = 1L;

@Id
private long id;
@Required(message="champ obligatoire")
private String nomEntreprise;
@Required(message="champ obligatoire")
private String adresse;
@Email(message="Email non valide")
@Required(message="champ obligatoire")
private String email;
@Required(message="champ obligatoire")
@Pattern(value="(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{8,}", message="Le mot de passe doit contenir au moins 8 caractère, une lettre majuscule, une lettre minuscule et un chiffre")
private String password;

    
    public Person(String nomEntreprise, String password, String email, String adresse){
        this.nomEntreprise=nomEntreprise;
        this.password=password;
        this.email=email;
        this.adresse=adresse;
    }
    
    public Person(){   
    }
    
    @OneToMany
    public List<Article> article;
    
    
    //Création d'un livre appartenant à un vendeur
    
    public boolean add(Article a){
        a.vendeur = this;
        return article.add(a);
    }
    
    
    
    public String getNomEntreprise(){
        return this.nomEntreprise;
    }
    
    public void setNomEntreprise(String nomEntreprise){
        this.nomEntreprise=nomEntreprise;
    }
    
    public long getId(){
        return this.id;
    }
    
    public long setId(long id){
        return this.id=id;
    }
    
    
    public String getPassword(){
        return this.password;
    }
    
    public void setPassword(String password){
        this.password=password;
    }
    
    public String getEmail(){
        return this.email;
    }
    
    public void setEmail(String email){
        this.email=email;
    }
    
    public String getAdresse(){
        return this.adresse;
    }
    
    public void setAdresse(String adresse){
        this.adresse=adresse;
    }
    
    public static Finder<Long, Person> find = new Finder<Long,Person>(Person.class);
}
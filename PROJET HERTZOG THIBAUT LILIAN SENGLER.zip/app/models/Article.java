package models ;

import java.util.*;
import io.ebean.*;
import javax.persistence.*;
import play.data.validation.Constraints.*;


@Entity
public class Article extends Model {
  
private static final long serialVersionUID = 1L;

@Id
private long articleId;   
@Required
private String name ;
@Required
private float price ; 
private String desc;
private boolean panier;
    
    public Article(String name, float price, String desc, boolean panier){
        this.name=name;
        this.price=price;
        this.desc=desc;
        this.panier=false;
    }
    
    public Article(){   
    }
    
    @ManyToOne
    public Person vendeur;
    
    public String getName(){
        return this.name;
    }
    
    public double getPrice(){
        return this.price;
    }
    
    public long getArticleId(){
        return this.articleId;
    }
    
    public void setArticleId(long articleId){
        this.articleId = articleId;
    }
    
    public void setPrice(float price){
        this.price = price;
    }
    
    public void setName(String name){
        this.name = name;
    }
    
    public void setPanier() {
        this.panier = true;
    }
    
    public boolean getPanier(){
        return this.panier;
    }
    
public static Finder<Long, Article> find = new Finder<Long,Article>(Article.class);
}